const figlet = require("figlet");
const name = "Jingle bell";


figlet(name, {
    font: "standard"
}, (err, result) => {
    console.log(err || result)
})
