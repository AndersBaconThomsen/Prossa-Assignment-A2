import { useState, useEffect } from 'react';
import './App.css';

function App() {

  const [aciiName, setAciiName] = useState("");

  useEffect(() => {
    let result = "";

    let namesplit = aciiName.split("");

    console.log(namesplit);

    namesplit.map(item => {
      let divElement = document.getElementById(item);
      divElement.classList.add("d-block");
      result += divElement.innerHTML;
    });

    document.getElementById("result").innerHTML = result

  }, [aciiName]);

  return (
    <>
      <main className="container">
        <form>
          <section className="row px-5 py-3">
            <h2>Create ASCII-Art</h2>

            <div className="d-none d-md-block col-md-3">
              <label htmlFor="ascii">Insert only letters for Ascii-Art</label>
            </div>
            <div className="col-md-2 mb-2 p-0">
              <input type="text" name="ascii" onChange={e => { setAciiName(e.target.value.toLowerCase()) }} />
            </div>
            <p id="result">

            </p>

            <div className="d-none" id="a" style={{ fontSize: "20px", marginBottom: "20px" }}>
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            <br />
            </div>

            <div className="d-none" id="b" style={{ fontSize: "20px", marginBottom: "20px" }}>
              -	&nbsp;* &nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;*	&nbsp;*	&nbsp;* <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;*	&nbsp;*	&nbsp;- <br />
            <br />
            </div>

            <div className="d-none" id="c" style={{ fontSize: "20px", marginBottom: "20px" }}>
              -	&nbsp;- &nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;*	&nbsp;*	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="d" style={{ fontSize: "20px", marginBottom: "20px" }}>
            -	&nbsp;* &nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;-	&nbsp;- <br />
            <br />
            </div>

            <div className="d-none" id="e" style={{ fontSize: "20px", marginBottom: "20px" }}>
              -	&nbsp;* &nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;*	&nbsp;- <br />
            <br />
            </div>

            <div className="d-none" id="f" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;* &nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;- &nbsp;-	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="g" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;- &nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;* &nbsp;* <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;-	&nbsp;* &nbsp;*	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="h" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;* &nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;* &nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;- &nbsp;*	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="i" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;- &nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;*	&nbsp;- &nbsp;- <br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;* &nbsp;-	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="j" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;- &nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;-	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;-	&nbsp;-	&nbsp;* &nbsp;- <br />
            -	&nbsp;-	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;* &nbsp;-	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="k" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;* &nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;- &nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;- &nbsp;*	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="l" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;* &nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;- &nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;* &nbsp;*	&nbsp;- <br /><br />
            </div>

            <div className="d-none" id="m" style={{ fontSize: "20px", marginBottom: "20px", }}>
              *	&nbsp;- &nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;* <br />
            *	&nbsp;-	&nbsp;*	&nbsp;- &nbsp;* <br />
            *	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;-	&nbsp;- &nbsp;-	&nbsp;* <br /><br />
            </div>

            <div className="d-none" id="n" style={{ fontSize: "20px", marginBottom: "20px", }}>
              *	&nbsp;- &nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;-	&nbsp;*	&nbsp;- &nbsp;* <br />
            *	&nbsp;-	&nbsp;-	&nbsp;*	&nbsp;* <br />
            *	&nbsp;-	&nbsp;- &nbsp;-	&nbsp;* <br /><br />
            </div>

            <div className="d-none" id="o" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;-	&nbsp;* &nbsp;*	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;*	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;*	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;* &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="p" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;*	&nbsp;* &nbsp;-	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- 	<br />
            -	&nbsp;*	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;- &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="q" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;-	&nbsp;* &nbsp;*	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;*	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;	&nbsp;-	&nbsp;*	<br />
            *	&nbsp;-	&nbsp;*	&nbsp;* &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="r" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;*	&nbsp;* &nbsp;-	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- 	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;*	&nbsp;-	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;* &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="s" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;-	&nbsp;* &nbsp;*	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;-	&nbsp;*	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;*	&nbsp;- &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="t" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;* &nbsp;*	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;-	&nbsp;* &nbsp;*	<br /><br />
            </div>

            <div className="d-none" id="u" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;- &nbsp;-	&nbsp;*	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;*	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;* &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="v" style={{ fontSize: "20px", marginBottom: "20px", }}>
            *	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;-	&nbsp;- &nbsp;-	&nbsp;*	<br />
            *	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;- &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="w" style={{ fontSize: "20px", marginBottom: "20px", }}>
            *	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;-	&nbsp;- &nbsp;-	&nbsp;*	<br />
            *	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;* <br />
            *	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;*	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;* &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="x" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;- <br />
            -	&nbsp;*	&nbsp;- &nbsp;*	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;*	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;-	&nbsp;* &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="y" style={{ fontSize: "20px", marginBottom: "20px", }}>
              *	&nbsp;-	&nbsp;-	&nbsp;-	&nbsp;* <br />
            -	&nbsp;*	&nbsp;- &nbsp;*	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;- &nbsp;-	<br /><br />
            </div>

            <div className="d-none" id="z" style={{ fontSize: "20px", marginBottom: "20px", }}>
              -	&nbsp;*	&nbsp;*	&nbsp;*	&nbsp;- <br />
            -	&nbsp;-	&nbsp;- &nbsp;*	&nbsp;-	<br />
            -	&nbsp;-	&nbsp;*	&nbsp;-	&nbsp;- <br />
            -	&nbsp;*	&nbsp;-	&nbsp;-	&nbsp;-	<br />
            -	&nbsp;*	&nbsp;*	&nbsp;* &nbsp;-	<br /><br />
            </div>

          </section>
        </form>
      </main>
    </>
  );
}

export default App;
  